package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    static final String server_url = "http://172.30.235.50:5000/upload/";  // 改成自己的url
    Context context;
    ActivityResultLauncher<Intent> someActivityResultLauncher;
    final static String[] readPermissions = {
            "android.permission.READ_EXTERNAL_STORAGE"
    };
    final static int REQUEST_CODE_READ_EXTERNAL_STORAGE = 200;  // 任意指定

    final static String[] writePermissions = {
            "android.permission.WRITE_EXTERNAL_STORAGE"
    };
    final static int REQUEST_CODE_WRITE_EXTERNAL_STORAGE = 201;  // 任意指定

    boolean hasImg = false;
    ImageView imageView;
    ImageView resImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        context = this;
        imageView = this.findViewById(R.id.upload_img);
        resImageView = this.findViewById(R.id.res_img);
        someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (imageView != null) {
                            imageView.setImageURI(data.getData());
                            hasImg = true;
                        } else {
                            Log.e("read error", "imageView is null");
                        }
                    }
                });
        initImgChooseBtn();
        initImgUploadBtn();
    }

    private void requestReadPermission() {
        this.requestPermissions(readPermissions, REQUEST_CODE_READ_EXTERNAL_STORAGE);
    }

    private void requestWritePermission() {
        this.requestPermissions(writePermissions, REQUEST_CODE_WRITE_EXTERNAL_STORAGE);
    }

    private void initImgChooseBtn() {
        Button btn = this.findViewById(R.id.img_choose_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 检查权限，没有权限就请求
                if (context.checkSelfPermission(readPermissions[0]) != PackageManager.PERMISSION_GRANTED) {
                    requestReadPermission();
                }
                // 打开相册
                openGallery();
            }
        });
    }

    private long getTimeCost(long startTime, String logStr) {
        long newTime = new Date().getTime();
        long res = (newTime - startTime);
        Log.d("timecost" + logStr, res + "milli secs");
        return newTime;  // 返回毫秒
    }

    private void initImgUploadBtn() {
        Button btn = this.findViewById(R.id.upload_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasImg == false) {
                    Toast.makeText(context, "请先选择图片", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 获取二进制图片
                Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream); // 可以选择其他压缩格式和压缩率
                byte[] bitmapData = stream.toByteArray();
                // 测试时间
                new Thread(()->{
                    // 发送请求
                    MediaType mediaType = MediaType.parse("image/jpeg");
                    RequestBody imageBody = RequestBody.create(bitmapData, mediaType);
                    MultipartBody.Builder builder = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("image", "local_img", imageBody);
                    RequestBody body = builder.build();
                    Request request = new Request.Builder()
                            .url(server_url)
                            .post(body)
                            .build();
                    OkHttpClient client = new OkHttpClient().newBuilder()
                            .connectTimeout(5, TimeUnit.SECONDS)
                            .build();
                    Call call = client.newCall(request);
                    try (Response response = call.execute()) {
                        // 把响应体保存到本地
                        byte[] resData = response.body().bytes();
                        if (context.checkSelfPermission(writePermissions[0]) != PackageManager.PERMISSION_GRANTED) {
                            requestWritePermission();
                        }
                        ImageSaver.saveImageToGallery(context, resData, "imageData");
                        runOnUiThread(()->{
                            // 设置ImageView为新的图片
                            ImageSaver.setImageToImageView(resImageView, resData);
                        });
                    } catch (IOException e) {
                        Log.e("request error", e.toString());
                    }
                }).start();

            }
        });
    }

    public void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        someActivityResultLauncher.launch(intent);
    }
}