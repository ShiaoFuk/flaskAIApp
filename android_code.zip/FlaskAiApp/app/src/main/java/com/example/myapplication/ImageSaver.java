package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

public class ImageSaver {
    public static void saveImageToGallery(Context context, byte[] imageBytes, String fileName) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);

        // 确定存储位置
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File imageFile = new File(storageDir, fileName + new Date().getTime() + ".jpg");

        try {
            // 创建文件输出流
            FileOutputStream fos = new FileOutputStream(imageFile);
            // 压缩Bitmap并写入文件
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();

            // 通知媒体扫描器，以便图片出现在相册中
            MediaScannerConnection.scanFile(context, new String[]{imageFile.getAbsolutePath()}, null, null);

        } catch (IOException e) {
            Log.e("saveImagetoGallery", e.toString());
        }
    }

    public static void setImageToImageView(ImageView imageView, byte[] imageBytes) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        imageView.setImageBitmap(bitmap);
    }
}
